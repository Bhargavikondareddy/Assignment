let login=( userName="CT" , passWord="CT")=> console.log(`Username:${userName} and Password is : ${passWord} `);
login("Bhargavi","Bhargavi@321")
login("Keerthi")