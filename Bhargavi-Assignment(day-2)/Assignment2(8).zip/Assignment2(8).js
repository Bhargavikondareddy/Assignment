function args(...a){
    sd = 0;
    for (const e of a){
        sd += e;
    }
    console.log(sd)
}
args()