function display(...args) {

    for (const b of args) {

        console.log(b);

    }



    console.log(`Total  Number of Arguments Passed : ${args.length}`);



}



display(28,92,16,51,85,94);