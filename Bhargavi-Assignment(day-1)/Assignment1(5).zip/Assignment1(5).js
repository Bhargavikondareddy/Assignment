let arr = [500,66,100,99,33,200,4];
let reverseArr=console.log(arr.reverse())

